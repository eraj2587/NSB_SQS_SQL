﻿using System.Threading.Tasks;
using NServiceBus;

using Shared;
using System;

#region PlaceOrderHandler

public class PlaceOrderHandler :
    IHandleMessages<PlaceOrder>
{
    public Task Handle(PlaceOrder message, IMessageHandlerContext context)
    {
        Console.WriteLine($"Order for Product:{message.Product} placed with id: {message.Id}");
        Console.WriteLine($"Publishing: OrderPlaced for Order Id: {message.Id}");

        var orderPlaced = new OrderPlaced
        {
            OrderId = message.Id
        };
        return context.Publish(orderPlaced);
    }
}

#endregion
