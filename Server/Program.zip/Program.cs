﻿using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.SQS;
using NHibernate.Cfg;
using NHibernate.Dialect;
using NServiceBus;
using NServiceBus.Persistence;
using NServiceBus.Transport.SQLServer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    class Program
    {
        static void Main(string[] args)
        {
            AsyncMain().GetAwaiter().GetResult();
        }

        private static async Task AsyncMain()
        {
            Console.Title = "NSB.Server";
           
            var endpointConfiguration = new EndpointConfiguration("NSB.Server");
            endpointConfiguration.UseSerialization<XmlSerializer>();
            endpointConfiguration.EnableInstallers();

            var persistence = endpointConfiguration.UsePersistence<NHibernatePersistence>();
            var nhConfig = new NHibernate.Cfg.Configuration();
            nhConfig.SetProperty(NHibernate.Cfg.Environment.ConnectionProvider, "NHibernate.Connection.DriverConnectionProvider");
            nhConfig.SetProperty(NHibernate.Cfg.Environment.ConnectionDriver, "NHibernate.Driver.Sql2008ClientDriver");
            nhConfig.SetProperty(NHibernate.Cfg.Environment.Dialect, "NHibernate.Dialect.MsSql2008Dialect");
            nhConfig.SetProperty(NHibernate.Cfg.Environment.ConnectionString, ConfigurationManager.ConnectionStrings["NSB_AWS.NHibernatePersistence"].ConnectionString);
            nhConfig.SetProperty(NHibernate.Cfg.Environment.DefaultSchema, "nsb");
            persistence.UseConfiguration(nhConfig);

            var transportType = ConfigurationManager.AppSettings["transportType"];

            if ((!string.IsNullOrEmpty(transportType) && transportType.ToUpper() == "SQL") || transportType == null)
            {
                var transport = 
                    endpointConfiguration.UseTransport<SqlServerTransport>()
                .ConnectionString(ConfigurationManager.ConnectionStrings["NSB_AWS.SqlServerTransport"].ConnectionString);
                transport.DefaultSchema("nsb");
            }
            else if (!string.IsNullOrEmpty(transportType) && transportType.ToUpper() == "SQS")
            {
                var S3BucketName = ConfigurationManager.AppSettings["S3BucketName"];
                var S3KeyPrefix = ConfigurationManager.AppSettings["S3KeyPrefix"];
                var transport = endpointConfiguration.UseTransport<SqsTransport>();
                transport.S3(S3BucketName, S3KeyPrefix);
            }

            endpointConfiguration.AuditProcessedMessagesTo("audit");
            endpointConfiguration.SendFailedMessagesTo("error");
            endpointConfiguration.EnableOutbox();

            var endpointInstance = await Endpoint.Start(endpointConfiguration)
                .ConfigureAwait(false);
            try
            {
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
            }
            finally
            {
                await endpointInstance.Stop()
                    .ConfigureAwait(false);
            }
        }
    }
}
